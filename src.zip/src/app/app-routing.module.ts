import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { OurproductComponent } from './ourproduct/ourproduct.component';
import { ContactComponent } from './contact/contact.component';
import { PageErrorComponent } from './page-error/page-error.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  
  {path:'',redirectTo:'login', pathMatch:'full'},
  {path:'home', component:HomeComponent},
  {path:'about_us',component:AboutusComponent},
  {path:'our_product', component:OurproductComponent},
  {path:'contact', component:ContactComponent},
  {path:'**', component:PageErrorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
